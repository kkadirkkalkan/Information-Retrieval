module.exports = {
	// Configure dev server for backend
	devServer: {
		proxy: 'http://localhost:1234'
	},
};